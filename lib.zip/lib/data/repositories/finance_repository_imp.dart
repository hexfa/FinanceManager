import 'package:finance_manager/domain/repositories/finance_repository.dart';

class FinanceRepositoryImp extends FinanceRepository {}
