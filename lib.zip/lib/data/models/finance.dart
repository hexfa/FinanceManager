class Finance {
  final int id;
  double value;

  Finance({required this.id, required this.value});
}
