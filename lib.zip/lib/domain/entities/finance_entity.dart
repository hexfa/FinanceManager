class FinanceEntity {
  final int id;
  double value;

  FinanceEntity({required this.id, required this.value});
}
